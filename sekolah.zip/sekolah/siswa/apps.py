from django.apps import AppConfig


class SiswaConfig(AppConfig):
    name = 'siswa'
