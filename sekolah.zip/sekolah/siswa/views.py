from django.shortcuts import render

# Create your views here.


def siswa(request):
    return render(request,'siswa/siswa.html')