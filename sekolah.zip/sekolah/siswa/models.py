from django.db import models

# Create your models here.

# nis,nama,jenis_kelamin,ttl,kelas,tahun_masuk,alamat,email,phone
class Siswa(models.Model):
    JENIS_KELAMIN = (
        ('L','laki-laki'),
        ('P','perempuan'),
    )
    
    nis = models.IntegerField()
    nama = models.CharField(max_length = 150)
    jenis_kelamin = models.CharField(max_length=1, choices=JENIS_KELAMIN)
    ttl = models.DateField(auto_now=False)
    kelas = models.IntegerField(max_length=1)
    tahun_masuk = models.DateField(auto_now=False)
    alamat = models.CharField(max_length = 250)
    # email = models.EmailField(max_length=%{2:254})
    phone = models.CharField(max_length = 10)
    
    def __str__(self):
        return self.nama
