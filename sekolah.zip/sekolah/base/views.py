from django.shortcuts import render

# Create your views here.

# from . import views


def index(request):
    return render(request, 'base/index.html')