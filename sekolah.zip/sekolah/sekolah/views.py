from django.shortcuts import render

def index (request):
    context = {
        'title' : 'SekolahKu',
        'bigheader' : 'Sekolah Tempat Menuntu Ilmu'

    }
    return render(request, 'index.html', context)